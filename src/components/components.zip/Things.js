export const Productos = [
	{name: 'Kawaii', link:'#'},
	{name: 'Ofertas', link:'#'},
	{name: 'Sobre Nosotros', link:'#'},
];

export const Logos = [
	{name: 'logo-facebook', link:'#'},
	{name: 'logo-twitter', link:'#'},
	{name: 'logo-instagram', link:'#'},
	{name: 'logo-github', link:'#'},
	{name: 'logo-slack', link:'#'},
];
